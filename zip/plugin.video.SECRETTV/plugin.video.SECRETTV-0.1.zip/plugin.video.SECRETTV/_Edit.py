import xbmcaddon

MainBase = 'https://pastebin.com/raw/aCQ132AH'
addon = xbmcaddon.Addon('plugin.video.SECRET TV')